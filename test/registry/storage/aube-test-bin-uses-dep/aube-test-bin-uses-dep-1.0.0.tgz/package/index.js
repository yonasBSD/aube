#!/usr/bin/env node
'use strict'
const dep = require('@pnpm.e2e/dep-of-pkg-with-1-dep')
console.log('Loaded inner dep:', dep().name)
