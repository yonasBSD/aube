#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const dir = process.env.INIT_CWD || '.';
fs.writeFileSync(path.join(dir, 'aube-transitive-bin-probe.txt'), 'transitive bin invoked\n');
