module.exports = { __source: 'jsr:@std/collections' };
